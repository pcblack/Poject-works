//
//  CollectionViewImagesCollectionViewCell.swift
//  HomerGames
//
//  Created by Vaibhav Dutt on 2021-08-05.
//

import UIKit

class CollectionViewImagesCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var cards: UIImageView!
    var myView : UIView!
    let frontTag: Int = 1
    var count: Int = 0
    var isopen = false
    var firstValue : UIImage!
    var secondValue : UIImage!
    var checkImage : [UIImage]!
    
    
    
    var frontImageView: UIImageView!
    
    
    func flipCardAnimation(card : UIImage,width: CGFloat){
        
       
        self.frontImageView  = UIImageView(image: card)
        
        
        frontImageView.frame = CGRect(x: 0, y: 0, width: width, height: width)
        frontImageView.layer.cornerRadius = 2.5
        frontImageView.layer.borderWidth = 5.0
        frontImageView.layer.borderColor = UIColor.black.cgColor
        frontImageView.clipsToBounds = true
       
        
            let transitionOptions = UIView.AnimationOptions.transitionFlipFromLeft
            UIView.transition(with: self.contentView, duration: 0.3, options: transitionOptions, animations: { [weak self]  () -> Void in
                        
                        self!.contentView.addSubview((self?.frontImageView!)!)

            }, completion: nil


       )
       
      
        }
        
    func backflip(card : UIImage,width: CGFloat)
        {
        
        self.frontImageView  = UIImageView(image: card)
        frontImageView.frame = CGRect(x: 0, y: 0, width: width, height: width)
        frontImageView.layer.cornerRadius = 2.5
        frontImageView.layer.borderWidth = 5.0
        frontImageView.layer.borderColor = UIColor.black.cgColor
        frontImageView.clipsToBounds = true
        
        
        let transitionOptions = UIView.AnimationOptions.transitionFlipFromLeft
        UIView.transition(with: self.contentView, duration: 1, options: transitionOptions, animations: { [weak self]  () -> Void in
                    
                    self!.contentView.addSubview((self?.frontImageView!)!)

        }, completion: { [self]finished in
            self.frontImageView  = UIImageView(image: UIImage(named: "allCardBacks"))
            frontImageView.frame = CGRect(x: 0, y: 0, width: width, height: width)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3, execute: {
                    let transitionOptions = UIView.AnimationOptions.transitionFlipFromLeft
                    UIView.transition(with: self.contentView, duration: 1, options: transitionOptions, animations: { [weak self]  () -> Void in
                                
                                self!.contentView.addSubview((self?.frontImageView!)!)

                    }, completion: nil)
                
                
                })
        })
       
    }

    func MatchFound(card : UIImage,width : CGFloat)
    {
        self.frontImageView  = UIImageView(image: card)
        frontImageView.frame = CGRect(x: 0, y: 0, width: width, height: width)
        frontImageView.layer.cornerRadius = 2.5
        frontImageView.layer.borderWidth = 5.0
        frontImageView.layer.borderColor = UIColor.black.cgColor
        frontImageView.clipsToBounds = true
        let transitionOptions = UIView.AnimationOptions.transitionFlipFromLeft
        UIView.transition(with: self.contentView, duration: 1, options: transitionOptions, animations: { [weak self]  () -> Void in
                    
                    self!.contentView.addSubview((self?.frontImageView!)!)

        }, completion: nil)
    }
    
    
    
}
