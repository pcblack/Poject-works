//
//  GamePlayViewController.swift
//  HomerGames
//
//  Created by Vaibhav Dutt on 2021-08-06.
//

import UIKit
import AVFoundation

class GamePlayViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var timer:Timer?
    var milliseconds:Double = 60 * 1000
    
    var AudioPlayer = AVAudioPlayer()
    
    let margin: CGFloat = 50
        var cellsPerRow = 0
    var numberOfCards = 0
    var y = 0
    var firstFlippedCard:IndexPath?
    var array = [UIImage]()
    var unique = [UIImage]()
    var collectionImages = [UIImage]()
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    @IBOutlet weak var timerLabel: UILabel!
    
    
    var checkIndex = [UIImage]()
    var imgViewFront : UIImageView!
    var imgViewBack : UIImageView!
    var backcard = UIImage(named:"allCardBacks")
    var front = UIImage(named:"memorySpiderCardFront")
    var itemWidth : CGFloat!
   // memorySpiderCardFront
    var cardsImages: [UIImage] = [
        UIImage(named:"memoryBatCardFront")!,
        UIImage(named:"memoryCatCardFront")!,
        UIImage(named:"memoryCowCardFront")!,
        UIImage(named:"memoryDragonFront")!,
        UIImage(named:"memoryGarbageManCardFront")!,
        UIImage(named:"memoryGhostDogCardFront")!,
        UIImage(named:"memoryHenCardFront")!,
        UIImage(named:"memoryHorseCardFront")!,
        UIImage(named:"memoryPigCardFront")!,
        UIImage(named:"memorySpiderCardFront")!,
        
    ]
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        //Create a Timer
        
        timer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(elapsedTimer), userInfo: nil, repeats: true)
        RunLoop.main.add(timer!, forMode: RunLoop.Mode.common)
        
        var x = numberOfCards/2
        var z = numberOfCards
        repeat{
            array.append(cardsImages.randomElement()!)
             unique = Array(Set(array))// getting unique half values
        
        }while unique.count < x
        while z>0 {
            collectionImages.append(unique[y])// crrating copy of those unique values
            z = z-1
            y = y+1
            if y==unique.count
            {
                y = 0
            }
        }
        
        
      
        print("I am Unique Array number is \(unique.count)")
        print("I am collection Array number is \(collectionImages)")
        //music
        
        let AssortedMusics = NSURL(fileURLWithPath: Bundle.main.path(forResource: "R1", ofType: "mp3")!)
        AudioPlayer = try! AVAudioPlayer(contentsOf: AssortedMusics as URL)
                AudioPlayer.prepareToPlay()
                AudioPlayer.numberOfLoops = -1
                AudioPlayer.play()
       // collectionView.addGestureRecognizer(tapGesture)
        imgViewBack = UIImageView(image:backcard )
        
    }
        

    override func viewWillLayoutSubviews() {
        guard let collectionView = collectionView, let flowLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout else { return }
                let marginsAndInsets = flowLayout.sectionInset.left + flowLayout.sectionInset.right + collectionView.safeAreaInsets.left + collectionView.safeAreaInsets.right + flowLayout.minimumInteritemSpacing * CGFloat(cellsPerRow - 1)
               itemWidth  = ((collectionView.bounds.size.width - marginsAndInsets) / CGFloat(cellsPerRow)).rounded(.down)
                flowLayout.itemSize =  CGSize(width: itemWidth, height: itemWidth)
       // print("Item width \(itemWidth)")
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("Number of items:\(numberOfCards)")
        return numberOfCards
    }
   
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewImagesCollectionViewCell
        print(indexPath)
       
        
        
        
       
        cell.cards.image = imgViewBack.image

        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell = collectionView.cellForItem(at: indexPath)as! CollectionViewImagesCollectionViewCell
        if checkIndex.contains(collectionImages[indexPath.row]) {
            print("Donot flip:\(collectionImages[indexPath.row])")
            cell.flipCardAnimation(card: collectionImages[indexPath.row],width: itemWidth)
            
        }
        else{
        
            print("value")
            
        if firstFlippedCard == nil {
            firstFlippedCard = indexPath
            cell.flipCardAnimation(card: collectionImages[indexPath.row],width: itemWidth)
        }
        else{
            checkForMatches(indexPath)
        }
        
        }
        
    }
    
    func checkForMatches(_ secondFlippedCard:IndexPath) {
        
//            get cells and cards
        let cellOne = collectionView.cellForItem(at: firstFlippedCard!) as? CollectionViewImagesCollectionViewCell
        let cellTwo = collectionView.cellForItem(at: secondFlippedCard) as? CollectionViewImagesCollectionViewCell
        let cardOne = collectionImages[firstFlippedCard!.row]
        let cardTwo = collectionImages[secondFlippedCard.row]
        
//            Card comparison
        
        if cardOne == cardTwo {
            
                checkIndex.append(cardOne)
            checkIndex.append(cardTwo)
            
            cellOne?.MatchFound(card: cardOne,width :itemWidth)
            cellTwo?.MatchFound(card: cardTwo,width :itemWidth)
            
            // Run logic to check if game has been won
            
        }
        else {
            
            
            cellOne?.backflip(card:cardOne,width :itemWidth)
            cellTwo?.backflip(card:cardTwo,width :itemWidth)
            
        }
        
//            Check if card is out of view and recycled
      
        
        firstFlippedCard = nil
    }
    
    
    //  MARK: - Timer Methods
    
    @objc func elapsedTimer(){
        //Method that updates the view label
        milliseconds -= 1
        
        //Convert it to a String for the label
//        let timeStr = String(milliseconds / 1000)
//        timerLabel.text = "Time Remaining: \(timeStr)"

        let seconds = String.init(format: "%.2f", milliseconds / 1000)
        timerLabel.text = "Time Remaining: \(seconds)"
        
        //Will stop at zero
        
        if milliseconds <= 0 {
            timer?.invalidate()
            timerLabel.textColor = UIColor.red
        }
//        // Check if game has ended
if milliseconds == 0
{
    if checkIndex.count == numberOfCards {
        let alert = UIAlertController(title: "Homer", message: "You Win", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Play Again", style: UIAlertAction.Style.default, handler: { [self]
            finsihed in
            AudioPlayer.stop()
            self.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
        
        
    }
    else
    {
        
            let alert = UIAlertController(title: "Homer", message: "One More Time", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Play Again", style: UIAlertAction.Style.default, handler: { [self]
                finished in
                AudioPlayer.stop()
                self.dismiss(animated: true, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
    
            
        print("You lose")
    
    print("I am zero");
    
}
//        checkIfGameEnded()
    }
    }
    
   
    
    
    
    @IBAction func backButton(_ sender: Any) {
        AudioPlayer.stop()
        dismiss(animated: true, completion: nil)
    }

    }
    
    


