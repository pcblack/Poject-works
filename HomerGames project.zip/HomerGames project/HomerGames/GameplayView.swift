//
//  GameplayView.swift
//  HomerGames
//
//  Created by Vaibhav Dutt on 2021-08-05.
//

import SwiftUI

struct GameplayView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct GameplayView_Previews: PreviewProvider {
    static var previews: some View {
        GameplayView()
    }
}
