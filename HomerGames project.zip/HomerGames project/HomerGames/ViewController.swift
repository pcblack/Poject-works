//
//  ViewController.swift
//  HomerGames
//
//  Created by Vaibhav Dutt on 2021-08-05.
//

import UIKit
//import AVFoundation

class ViewController: UIViewController {
//    var AudioPlayer = AVAudioPlayer()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    
    

    @IBAction func startGame(_ sender: UIButton) {
        
        print("Button Clicked")
        let vc = (storyboard?.instantiateViewController(identifier: "gameplay"))! as GamePlayViewController
        switch sender.tag {
        case 1:
            vc.cellsPerRow = 4
            vc.numberOfCards = 12
            break
        case 2: vc.cellsPerRow = 2
            vc.numberOfCards = 10
            break
        case 3:
            vc.cellsPerRow = 4
            vc.numberOfCards = 16
            break
        case 4:
            vc.cellsPerRow = 5
            vc.numberOfCards = 20
            break
        default:
            print("Nothing get from tag value")
        }
    
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
}

