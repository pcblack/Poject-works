//
//  ViewController.swift
//  Speer Technologies iOS assessment
//
//  Created by Vaibhav Dutt on 2021-09-29.
//

import UIKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    @IBOutlet weak var search: UISearchBar!
    var userName : String!
    
    @IBOutlet weak var lblMessage: UILabel!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        lblMessage.isHidden = true
    }

    @IBAction func gitUser(_ sender: Any) {
        userName = search.text?.uppercased()
        
        
        let URL = "https://api.github.com/users/"+self.userName
        print(URL)
        
        AF.request(URL).responseJSON { [self]
            // 1. store the data from the internet in the
            // response variable
            response in

            // 2. get the data out of the variable
            guard let apiData = response.data else {
                print("Error getting data from the URL")
                self.lblMessage.isHidden = false
                self.lblMessage.text = "NO User"
                
                return
            }

            // OUTPUT the json response to the terminal
            print(apiData)


            // GET something out of the JSON response
            let jsonResponse = JSON(apiData)
        
            let vc = (self.storyboard?.instantiateViewController(identifier: "display"))! as DisplayViewController
            let navVc = UINavigationController(rootViewController: vc)
            
            
            
            vc.avatar = jsonResponse["avatar_url"].string
            vc.UserName = jsonResponse["login"].string
            vc.Name = jsonResponse["name"].string
            vc.email = jsonResponse["email"].string
            vc.company = jsonResponse["company"].string
            vc.followingCount = jsonResponse["following"].int
            vc.followersCount = jsonResponse["followers"].int
            vc.avatar = jsonResponse["avatar_url"].string
            navVc.modalPresentationStyle = .fullScreen
            self.lblMessage.isHidden = true
            self.present(navVc, animated: true, completion: nil)


            
    }
        
    }
    
}

