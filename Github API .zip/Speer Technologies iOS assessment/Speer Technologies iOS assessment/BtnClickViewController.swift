//
//  BtnClickViewController.swift
//  Speer Technologies iOS assessment
//
//  Created by Vaibhav Dutt on 2021-09-30.
//

import UIKit
import Alamofire
import SwiftyJSON
class BtnClickViewController: UIViewController{

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    
    var loginID : [String] = []
    var imageArray : [String] = []
    var image : UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        tableView.delegate = self
        tableView.dataSource = self
        
    }
    
    
}



extension BtnClickViewController : UITableViewDelegate
{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let URL = "https://api.github.com/users/"+self.loginID[indexPath.row].uppercased()
        print(URL)
        
        AF.request(URL).responseJSON { [self]
            // 1. store the data from the internet in the
            // response variable
            response in

            // 2. get the data out of the variable
            guard let apiData = response.data else {
                print("Error getting data from the URL")
                return
            }

            // OUTPUT the json response to the terminal
            print(apiData)


            // GET something out of the JSON response
            let jsonResponse = JSON(apiData)
            
            let vc = (self.storyboard?.instantiateViewController(identifier: "display"))! as DisplayViewController
            let navVc = UINavigationController(rootViewController: vc)
            
            
            
            vc.avatar = jsonResponse["avatar_url"].string
            vc.UserName = jsonResponse["login"].string
            vc.followingCount = jsonResponse["following"].int
            vc.followersCount = jsonResponse["followers"].int
            vc.avatar = jsonResponse["avatar_url"].string
            vc.Name = jsonResponse["name"].string
            vc.email = jsonResponse["email"].string
            vc.company = jsonResponse["company"].string
            navVc.modalPresentationStyle = .fullScreen
            self.present(navVc, animated: true, completion: nil)


            
    }
        
    }
    }

extension BtnClickViewController:UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        loginID.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let  cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableCellTableViewCell
        cell.cellLable.text = loginID[indexPath.row]
        let url = URL(string:imageArray[indexPath.row])
            if let data = try? Data(contentsOf: url!)
            {
                let image: UIImage = UIImage(data: data)!
                cell.cellImage.image = image
            }
            
        
        
                
        return cell
    }
   
   
}
