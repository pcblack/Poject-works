//
//  DisplayViewController.swift
//  Speer Technologies iOS assessment
//
//  Created by Vaibhav Dutt on 2021-09-29.
//

import UIKit
import Alamofire
import SwiftyJSON
class DisplayViewController: UIViewController {
    

    @IBOutlet weak var avatarImage: UIImageView!
    
    
    @IBOutlet weak var lblUserName: UILabel!
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBOutlet weak var lblemail: UILabel!
    
    
    @IBOutlet weak var lblcompany: UILabel!
    
    @IBOutlet weak var btnFollowing: UIButton!
    
    
    @IBOutlet weak var btnfollower: UIButton!
    var uRL : String!
    var avatar:String!
    var UserName : String!
    var Name : String!
    var email : String!
    var company : String!
    var followersCount : Int!
    var followingCount : Int!
    var number : Int!
    var loginID : [String] = []
    var image : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = UserName
        
        avatar == nil ? (avatarImage.image = UIImage(named:"DownArrowColor.png")):(setImage(from: avatar))
        lblUserName.text = "UserName" + "  " + (UserName == nil ? "not available" : UserName)
        lblName.text = "Name" + "  " + (Name == nil ? "not available" : Name)
        lblemail.text = "Email" + "  " + (email == nil ? "not available" : email)
        lblcompany.text = "Company" + "  " + (company == nil ? "not available" : company)
        btnfollower.setTitle("Followers" + "  " +  String(self.followersCount==nil ?0:self.followersCount ), for: .normal)
        btnFollowing.setTitle("Following" + "  " + String(self.followingCount==nil ?0:self.followingCount ), for: .normal)
        
        followingCount>0 ? (btnFollowing.isEnabled = true) : (btnFollowing.isEnabled = false)
        followersCount>0 ? (btnfollower.isEnabled = true) : (btnfollower.isEnabled = false)
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(dismissSelf))
      
    }
    
    
    
    func setImage(from url: String) {
        guard let imageURL = URL(string: url) else { return }

            // just not to cause a deadlock in UI!
        DispatchQueue.global().async {
            guard let imageData = try? Data(contentsOf: imageURL) else { return }

            let image = UIImage(data: imageData)
            DispatchQueue.main.async {
                self.avatarImage.image = image
            }
        }
       
    }

    
    @IBAction func btnAction(_ sender: UIButton) {
        let vc = (self.storyboard?.instantiateViewController(identifier: "SecondaryViewController"))! as BtnClickViewController

        let clickTag = sender.tag
        if clickTag == 1
        {
            uRL = "https://api.github.com/users/"+self.UserName.uppercased()+"/"+"followers"
            vc.title = "Followers"
            number = followersCount
            
        }
        else if clickTag == 2
        {
            uRL = "https://api.github.com/users/"+self.UserName.uppercased()+"/"+"following"
            vc.title = "Following"
            number = followingCount
        }
        
        
        AF.request(uRL).responseJSON { [self]
            
                // 1. store the data from the internet in the
                // response variable
                response in

                // 2. get the data out of the variable
                guard let apiData = response.data else {
                    print("Error getting data from the URL")
                    return
                }

                // OUTPUT the json response to the terminal
                print(apiData)
            
                // GET something out of the JSON response
                let jsonResponse = JSON(apiData)
                print("pc")
                var i = 0
                while(i < jsonResponse.count)
                {
                   print("I am not here")
                    loginID.append(jsonResponse[i]["login"].string ?? "na")
                    
                    image.append(jsonResponse[i]["avatar_url"].string!)
                    i = i + 1
                    
                }
            
               for value in loginID{
                   
               vc.loginID.append(value)
               }
               for value in image {
                print(value)
                   vc.imageArray.append(value)
               }
            
            vc.modalPresentationStyle = .overFullScreen
           
            navigationController?.pushViewController(vc, animated: true)
           
            }
           
        
     
        }
        

    @objc private func dismissSelf(){
        dismiss(animated: true, completion: nil)
    }
    
}

