//
//  TableCellTableViewCell.swift
//  Speer Technologies iOS assessment
//
//  Created by Vaibhav Dutt on 2021-10-01.
//

import UIKit

class TableCellTableViewCell: UITableViewCell {

    @IBOutlet weak var cellLable: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
