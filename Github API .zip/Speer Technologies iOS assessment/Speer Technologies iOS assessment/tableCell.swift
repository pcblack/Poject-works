//
//  tableCell.swift
//  Speer Technologies iOS assessment
//
//  Created by Vaibhav Dutt on 2021-10-01.
//

import Foundation
